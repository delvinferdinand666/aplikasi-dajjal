
import csv
from pathlib import Path
from datetime import datetime, timedelta, timezone

from flask import Flask, render_template, request, redirect, url_for, jsonify

app = Flask(__name__)

# Lokasi file CSV
CSV_FILE = Path(__file__).parent / "data" / "user.csv"

# Nama kolom CSV
FIELDNAMES = ["id", "fullname", "email", "phone", "notes", "registeredAt"]


# ==========================================
# HELPER FUNCTIONS
# ==========================================

# 1. Membuat file CSV jika belum tersedia
def ensure_csv():
    CSV_FILE.parent.mkdir(parents=True, exist_ok=True)

    if not CSV_FILE.exists() or CSV_FILE.stat().st_size == 0:
        with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
            writer.writeheader()


# 2. Mengambil seluruh data dari CSV
def load_data():
    ensure_csv()

    users = []

    with open(CSV_FILE, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            if row.get("id"):
                users.append(row)

    return users


# 3. Menyimpan data ke CSV
def save_data(users):
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(users)


# 4. Membuat ID baru
def generate_id(users):
    ids = []

    for user in users:
        ids.append(int(user["id"]))

    new_id = max(ids, default=0) + 1

    return str(new_id)


# 5. Mengambil waktu pendaftaran
def get_time():
    timezone_gmt7 = timezone(timedelta(hours=7))

    return datetime.now(timezone_gmt7).strftime(
        "%d/%m/%Y %H:%M GMT+7"
    )


# 6. Mencari user berdasarkan ID
def find_user(users, user_id):
    for user in users:
        if user["id"] == user_id:
            return user

    return None


# ==========================================
# PAGE ROUTES
# ==========================================

# Homepage - GET
@app.route("/", methods=["GET"])
def home():
    users = load_data()

    edit_id = request.args.get("edit")
    edit_user = None

    if edit_id:
        edit_user = find_user(users, edit_id)

        if edit_user is None:
            return render_template("error.html"), 404

    return render_template(
        "index.html",
        users=users,
        total=len(users),
        edit_user=edit_user
    )


# User Detail Page - GET
@app.route("/userdetails/<user_id>", methods=["GET"])
def user_details(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return render_template("error.html"), 404

    return render_template(
        "userdetails.html",
        user=user,
        total=len(users)
    )


# Error Page - GET
@app.route("/error", methods=["GET"])
def error_page():
    return render_template("error.html")


# ==========================================
# FORM ROUTES
# Digunakan oleh HTML Form (POST)
# ==========================================

# Register - POST
@app.route("/register", methods=["POST"])
def register():
    fullname = request.form.get("fullname", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip() or "-"
    notes = request.form.get("notes", "").strip() or "-"

    if not fullname or not email:
        return "Full name and email are required.", 400

    users = load_data()

    new_user = {
        "id": generate_id(users),
        "fullname": fullname,
        "email": email,
        "phone": phone,
        "notes": notes,
        "registeredAt": get_time()
    }

    users.append(new_user)

    save_data(users)

    return redirect(url_for("home"))


# Update Registration - POST
@app.route("/update/<user_id>", methods=["POST"])
def update_registration(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return render_template("error.html"), 404

    fullname = request.form.get("fullname", "").strip()
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip() or "-"
    notes = request.form.get("notes", "").strip() or "-"

    if not fullname or not email:
        return "Full name and email are required.", 400

    user["fullname"] = fullname
    user["email"] = email
    user["phone"] = phone
    user["notes"] = notes

    save_data(users)

    return redirect(url_for("home"))


# Delete Registration - POST
@app.route("/delete/<user_id>", methods=["POST"])
def delete_registration(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return render_template("error.html"), 404

    users.remove(user)

    save_data(users)

    return redirect(url_for("home"))


# ==========================================
# API ROUTES
# GET, POST, PUT, DELETE
# ==========================================

# GET: Mengambil seluruh data pendaftar
@app.route("/api/registrations", methods=["GET"])
def get_registrations():
    users = load_data()

    return jsonify({
        "registrations": users,
        "total": len(users)
    }), 200


# GET: Mengambil detail satu pendaftar
@app.route("/api/registrations/<user_id>", methods=["GET"])
def get_registration(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return jsonify({
            "error": "Registration not found."
        }), 404

    return jsonify({
        "registration": user
    }), 200


# POST: Membuat pendaftaran baru melalui API
@app.route("/api/registrations", methods=["POST"])
def create_registration():
    data = request.get_json(silent=True) or {}

    fullname = data.get("fullname", "").strip()
    email = data.get("email", "").strip()
    phone = data.get("phone", "").strip() or "-"
    notes = data.get("notes", "").strip() or "-"

    if not fullname or not email:
        return jsonify({
            "error": "Name and email are required."
        }), 400

    users = load_data()

    new_user = {
        "id": generate_id(users),
        "fullname": fullname,
        "email": email,
        "phone": phone,
        "notes": notes,
        "registeredAt": get_time()
    }

    users.append(new_user)

    save_data(users)

    return jsonify({
        "message": "Registration created successfully.",
        "registration": new_user
    }), 201


# PUT: Mengubah data pendaftar melalui API
@app.route("/api/registrations/<user_id>", methods=["PUT"])
def update_registration_api(user_id):
    data = request.get_json(silent=True) or {}

    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return jsonify({
            "error": "Registration not found."
        }), 404

    fullname = data.get("fullname", user["fullname"]).strip()
    email = data.get("email", user["email"]).strip()
    phone = data.get("phone", user["phone"]).strip() or "-"
    notes = data.get("notes", user["notes"]).strip() or "-"

    if not fullname or not email:
        return jsonify({
            "error": "Name and email are required."
        }), 400

    user["fullname"] = fullname
    user["email"] = email
    user["phone"] = phone
    user["notes"] = notes

    save_data(users)

    return jsonify({
        "message": "Registration updated successfully.",
        "registration": user
    }), 200


# DELETE: Menghapus data pendaftar melalui API
@app.route("/api/registrations/<user_id>", methods=["DELETE"])
def delete_registration_api(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return jsonify({
            "error": "Registration not found."
        }), 404

    users.remove(user)

    save_data(users)

    return jsonify({
        "message": "Registration deleted successfully."
    }), 200


# ==========================================
# RUN APPLICATION
# ==========================================

if __name__ == "__main__":
    ensure_csv()
    app.run(debug=True)
