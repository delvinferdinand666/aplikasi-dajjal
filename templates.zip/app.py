
import csv
from pathlib import Path
from datetime import datetime, timedelta, timezone
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Lokasi penyimpanan CSV
CSV_FILE = Path(__file__).parent / "data" / "user.csv"

# Nama kolom CSV
FIELDNAMES = ["id", "fullname", "email", "phone", "notes", "registeredAt"]


# 1. Membuat file CSV jika belum tersedia
def ensure_csv():
    CSV_FILE.parent.mkdir(parents=True, exist_ok=True)

    if not CSV_FILE.exists() or CSV_FILE.stat().st_size == 0:
        with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
            writer.writeheader()


# 2. Mengambil seluruh data dari CSV
def load_data():
    ensure_csv()

    users = []

    with open(CSV_FILE, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            if row.get("id"):
                users.append(row)

    return users


# 3. Menyimpan data ke CSV
def save_data(users):
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)

        writer.writeheader()
        writer.writerows(users)


# 4. Membuat ID baru
def generate_id(users):
    ids = []

    for user in users:
        ids.append(int(user["id"]))

    new_id = max(ids, default=0) + 1

    return str(new_id)


# 5. Mengambil waktu pendaftaran
def get_time():
    timezone_gmt7 = timezone(timedelta(hours=7))

    return datetime.now(timezone_gmt7).strftime("%d/%m/%Y %H:%M GMT+7")


# 6. Mencari user berdasarkan ID
def find_user(users, user_id):
    for user in users:
        if user["id"] == user_id:
            return user

    return None


# ==================================================
# PAGE ROUTES
# ==================================================

# Homepage
@app.route("/")
def home():
    users = load_data()

    return render_template(
        "index.html",
        users=users,
        total=len(users)
    )


# User Detail Page
@app.route("/userdetails/<user_id>")
def user_details(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return render_template("error.html"), 404

    return render_template(
        "userdetails.html",
        user=user,
        total=len(users)
    )


# Error Page
@app.route("/error")
def error_page():
    return render_template("error.html")


# ==================================================
# API ROUTES
# ==================================================

# GET: Mengambil seluruh data pendaftar
@app.route("/api/registrations", methods=["GET"])
def get_registrations():
    users = load_data()

    return jsonify({
        "registrations": users,
        "total": len(users)
    }), 200


# GET: Mengambil detail satu pendaftar
@app.route("/api/registrations/<user_id>", methods=["GET"])
def get_registration(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return jsonify({"error": "Registration not found."}), 404

    return jsonify({
        "registration": user,
        "total": len(users)
    }), 200


# POST: Membuat pendaftaran baru
@app.route("/api/registrations", methods=["POST"])
def create_registration():
    data = request.get_json() or {}

    fullname = data.get("fullname", "").strip()
    email = data.get("email", "").strip()
    phone = data.get("phone", "").strip() or "-"
    notes = data.get("notes", "").strip() or "-"

    if not fullname or not email:
        return jsonify({"error": "Name and email are required."}), 400

    users = load_data()

    new_user = {
        "id": generate_id(users),
        "fullname": fullname,
        "email": email,
        "phone": phone,
        "notes": notes,
        "registeredAt": get_time()
    }

    users.append(new_user)

    save_data(users)

    return jsonify({
        "message": "Registration created successfully.",
        "registration": new_user
    }), 201


# PUT: Mengubah data pendaftar
@app.route("/api/registrations/<user_id>", methods=["PUT"])
def update_registration(user_id):
    data = request.get_json() or {}

    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return jsonify({"error": "Registration not found."}), 404

    fullname = data.get("fullname", "").strip()
    email = data.get("email", "").strip()

    if not fullname or not email:
        return jsonify({"error": "Name and email are required."}), 400

    user["fullname"] = fullname
    user["email"] = email
    user["phone"] = data.get("phone", "").strip() or "-"
    user["notes"] = data.get("notes", "").strip() or "-"

    save_data(users)

    return jsonify({
        "message": "Registration updated successfully.",
        "registration": user
    }), 200


# DELETE: Menghapus data pendaftar
@app.route("/api/registrations/<user_id>", methods=["DELETE"])
def delete_registration(user_id):
    users = load_data()

    user = find_user(users, user_id)

    if user is None:
        return jsonify({"error": "Registration not found."}), 404

    new_users = []

    for item in users:
        if item["id"] != user_id:
            new_users.append(item)

    save_data(new_users)

    return jsonify({
        "message": "Registration deleted successfully.",
        "total": len(new_users)
    }), 200


# ==================================================
# RUN APPLICATION
# ==================================================

if __name__ == "__main__":
    ensure_csv()
    app.run(debug=True)
