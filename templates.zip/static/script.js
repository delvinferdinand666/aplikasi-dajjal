
// Menunggu HTML selesai dimuat
document.addEventListener("DOMContentLoaded", function () {

    // ==========================================
    // INDEX PAGE
    // ==========================================

    const submitBtn = document.querySelector(".submit-btn");

    if (submitBtn) {

        const fullname = document.getElementById("fullname");
        const email = document.getElementById("email");
        const phone = document.getElementById("phonenumber");
        const notes = document.getElementById("notes");

        const title = document.querySelector(".registration_title");

        // Memeriksa apakah URL memiliki ?edit=ID
        const params = new URLSearchParams(window.location.search);
        const editId = params.get("edit");


        // Jika sedang edit, ambil data lama dari API GET
        if (editId) {

            fetch(`/api/registrations/${encodeURIComponent(editId)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Registration not found");
                    }

                    return response.json();
                })

                .then(data => {

                    const user = data.registration;

                    fullname.value = user.fullname;
                    email.value = user.email;
                    phone.value = user.phone === "-" ? "" : user.phone;
                    notes.value = user.notes === "-" ? "" : user.notes;

                    title.textContent = "Edit Registration";
                    submitBtn.textContent = "Update";

                })

                .catch(error => {
                    alert(error.message);
                    window.location.href = "/";
                });

        }


        // Register atau Update
        submitBtn.addEventListener("click", async function () {

            const userData = {
                fullname: fullname.value.trim(),
                email: email.value.trim(),
                phone: phone.value.trim(),
                notes: notes.value.trim()
            };

            // Validasi input
            if (!userData.fullname || !userData.email) {
                alert("Please fill in Full name and Email.");
                return;
            }

            // Menentukan API method
            let url = "/api/registrations";
            let method = "POST";

            if (editId) {
                url = `/api/registrations/${encodeURIComponent(editId)}`;
                method = "PUT";
            }

            submitBtn.disabled = true;

            try {

                const response = await fetch(url, {
                    method: method,

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify(userData)
                });

                const result = await response.json();

                if (!response.ok) {
                    throw new Error(result.error);
                }

                alert(result.message);

                // Kembali ke homepage untuk menampilkan data terbaru
                window.location.href = "/";

            } catch (error) {

                alert(error.message);

            } finally {

                submitBtn.disabled = false;

            }

        });


        // Delete dari homepage
        const deleteButtons = document.querySelectorAll(".delete_button");

        deleteButtons.forEach(function (button) {

            button.addEventListener("click", async function () {

                const userId = button.dataset.id;

                const confirmDelete = confirm(
                    "Are you sure you want to delete this registration?"
                );

                if (!confirmDelete) {
                    return;
                }

                button.disabled = true;

                try {

                    const response = await fetch(
                        `/api/registrations/${encodeURIComponent(userId)}`,
                        {
                            method: "DELETE"
                        }
                    );

                    const result = await response.json();

                    if (!response.ok) {
                        throw new Error(result.error);
                    }

                    alert(result.message);

                    window.location.href = "/";

                } catch (error) {

                    alert(error.message);
                    button.disabled = false;

                }

            });

        });

    }


    // ==========================================
    // USER DETAILS PAGE
    // ==========================================

    const detailCard = document.querySelector(".detail_card");

    if (detailCard) {

        // Mengambil ID dari URL
        // Contoh: /userdetails/1
        const parts = window.location.pathname.split("/");
        const userId = parts[2];


        // Tombol Back
        const backBtn = detailCard.querySelector(".backtolist-btn");

        backBtn.addEventListener("click", function () {

            window.location.href = "/";

        });


        // Tombol Edit
        const editBtn = detailCard.querySelector(".edit-btn");

        editBtn.addEventListener("click", function () {

            window.location.href = `/?edit=${encodeURIComponent(userId)}`;

        });


        // Tombol Delete
        const deleteBtn = detailCard.querySelector(".delete-detail-btn");

        deleteBtn.addEventListener("click", async function () {

            const confirmDelete = confirm(
                "Are you sure you want to delete this registration?"
            );

            if (!confirmDelete) {
                return;
            }

            deleteBtn.disabled = true;

            try {

                const response = await fetch(
                    `/api/registrations/${encodeURIComponent(userId)}`,
                    {
                        method: "DELETE"
                    }
                );

                const result = await response.json();

                if (!response.ok) {
                    throw new Error(result.error);
                }

                alert(result.message);

                window.location.href = "/";

            } catch (error) {

                alert(error.message);
                deleteBtn.disabled = false;

            }

        });

    }


    // ==========================================
    // ERROR PAGE
    // ==========================================

    const errorBtn = document.querySelector(".error-btn");

    if (errorBtn) {

        errorBtn.addEventListener("click", function () {

            window.location.href = "/";

        });

    }

});
